public class ClockTest
{

    public static void main(String[] args)
    {
        Clock myClock = new Clock();
        myClock.setHour(10);
        myClock.setMinutes(15);
        myClock.setSeconds(47);
        myClock.displayTime();
    }
}
